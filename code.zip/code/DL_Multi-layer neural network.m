% Read data from the first file
data1 = xlsread('1_raw_data_13-12_22.03.16.xlsx');
time1 = data1(:, 1); % Time column
emg_signals1 = data1(:, 2:9); % 8 EMG channels
labels1 = data1(:, 10); % Gesture labels

% Read data from the second file
data2 = xlsread('2_raw_data_13-13_22.03.16.xlsx');
time2 = data2(:, 1); % Time column
emg_signals2 = data2(:, 2:9); % 8 EMG channels
labels2 = data2(:, 10); % Gesture labels

% Combine data
time = [time1; time2];
emg_signals = [emg_signals1; emg_signals2];
labels = [labels1; labels2];

% Data preprocessing
fs = 1000; % Assume sampling frequency is 1000Hz
[b, a] = butter(4, [20 450] / (fs / 2), 'bandpass'); % Bandpass filter (20-450 Hz)
filtered_emg = filtfilt(b, a, emg_signals);

% Remove baseline drift
baseline = mean(filtered_emg, 1);
filtered_emg = filtered_emg - baseline;

% Amplify the signal
amplified_emg = filtered_emg * 1e5;

% Gaussian filtering
gaussian_filter = fspecial('gaussian', [5 1], 2);
filtered_emg = conv2(amplified_emg, gaussian_filter, 'same');

% Data normalization
normalized_emg = (filtered_emg - min(filtered_emg(:))) / (max(filtered_emg(:)) - min(filtered_emg(:)));

% Feature extraction
window_size = 250;
overlap = 200; % Increase overlap ratio
num_windows = floor((length(normalized_emg) - window_size) / (window_size - overlap)) + 1;

rms_features = zeros(num_windows, 8);
mav_features = zeros(num_windows, 8);
wl_features = zeros(num_windows, 8);
zcr_features = zeros(num_windows, 8);
var_features = zeros(num_windows, 8);
fft_features = zeros(num_windows, 8);
spectral_entropy = zeros(num_windows, 8);
relative_energy = zeros(num_windows, 8);
window_labels = zeros(num_windows, 1);

for i = 1:num_windows
    start_idx = (i-1) * (window_size - overlap) + 1;
    end_idx = start_idx + window_size - 1;
    if end_idx > length(normalized_emg)
        break;
    end
    window_data = normalized_emg(start_idx:end_idx, :);
    rms_features(i, :) = rms(window_data);
    mav_features(i, :) = mean(abs(window_data));
    wl_features(i, :) = sum(abs(diff(window_data)));
    
    % Calculate ZCR features
    for ch = 1:8
        zcr_features(i, ch) = sum(diff(window_data(:, ch) > 0) ~= 0) / length(window_data(:, ch));
    end
    
    var_features(i, :) = var(window_data);
    fft_data = abs(fft(window_data));
    fft_features(i, :) = mean(fft_data(2:window_size/2+1, :));
    spectral_entropy(i, :) = -sum((fft_data ./ sum(fft_data)).*log2(fft_data ./ sum(fft_data)));
    relative_energy(i, :) = sum(fft_data.^2) / sum(fft_data(:).^2);
    
    window_segment_labels = labels(start_idx:end_idx);
    unique_labels = unique(window_segment_labels);
    counts = histc(window_segment_labels, unique_labels);
    [~, max_idx] = max(counts);
    window_labels(i) = unique_labels(max_idx);
end

% Combine features
all_features = [rms_features, mav_features, wl_features, zcr_features, var_features, fft_features, spectral_entropy, relative_energy];
valid_idx = window_labels > 0;
all_features = all_features(valid_idx, :);
window_labels = window_labels(valid_idx);

% Data partitioning (training and test sets)
train_ratio = 0.7;
num_train = round(size(all_features, 1) * train_ratio);

train_data = all_features(1:num_train, :);
train_labels = window_labels(1:num_train);

test_data = all_features(num_train+1:end, :);
test_labels = window_labels(num_train+1:end);

% Convert labels to categorical outputs
num_classes = length(unique(window_labels));
train_labels_categorical = categorical(train_labels, 1:num_classes);
test_labels_categorical = categorical(test_labels, 1:num_classes);

% Define a more complex neural network structure
layers = [
    featureInputLayer(size(train_data, 2))
    fullyConnectedLayer(128)
    reluLayer
    fullyConnectedLayer(64)
    reluLayer
    fullyConnectedLayer(32)
    reluLayer
    fullyConnectedLayer(num_classes)
    softmaxLayer
    classificationLayer
];

% Train the neural network
options = trainingOptions('adam', ...
    'MaxEpochs', 50, ... % Increase training epochs
    'MiniBatchSize', 128, ... % Increase mini-batch size
    'Plots', 'training-progress', ...
    'ValidationData', {test_data, test_labels_categorical});

net = trainNetwork(train_data, train_labels_categorical, layers, options);

% Predict and evaluate
predicted_labels_nn = classify(net, test_data);
confusion_matrix_nn = confusionmat(test_labels_categorical, predicted_labels_nn);
accuracy_nn = sum(diag(confusion_matrix_nn)) / sum(confusion_matrix_nn(:));

disp('Neural Network Confusion Matrix:');
disp(confusion_matrix_nn);
disp(['Neural Network Classification Accuracy: ', num2str(accuracy_nn * 100), '%']);

% 可视化神经网络结构
figure;
plot(layerGraph(layers));
title('Neural Network Architecture');

% Visualize results
figure;
confusionchart(confusion_matrix_nn);
title('Neural Network Confusion Matrix');

% Generate voltage vs. time plots
figure;
for i = 1:8
    subplot(8, 1, i);
    plot(time, emg_signals(:, i));
    title(['Channel ', num2str(i), ' Voltage vs. Time']);
    xlabel('Time (ms)');
    ylabel('Voltage (V)');
end

% Generate feature plots
feature_names = {'RMS', 'MAV', 'WL', 'ZCR', 'Variance', 'FFT', 'Spectral Entropy', 'Relative Energy'};
features = {rms_features, mav_features, wl_features, zcr_features, var_features, fft_features, spectral_entropy, relative_energy};

for j = 1:length(features)
    figure;
    plot(features{j});
    title([feature_names{j}, ' Features']);
    xlabel('Window');
    ylabel([feature_names{j}, ' Value']);
    legend('Channel 1', 'Channel 2', 'Channel 3', 'Channel 4', 'Channel 5', 'Channel 6', 'Channel 7', 'Channel 8');
end
